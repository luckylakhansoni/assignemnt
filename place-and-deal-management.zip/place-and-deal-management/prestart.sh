#!/bin/bash
eslint --ignore-path .eslintignore .