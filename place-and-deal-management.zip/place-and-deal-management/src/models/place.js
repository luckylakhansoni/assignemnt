import mongoose from 'mongoose'

const Place = new mongoose.Schema({
	userId: {
		type: mongoose.Types.ObjectId,
		ref: 'users'
	},
	name: {
		type: String
	},
	description: {
		type: String
	},
	isApproved: {
		type: String
	}
})
export default mongoose.model('place', Place)
