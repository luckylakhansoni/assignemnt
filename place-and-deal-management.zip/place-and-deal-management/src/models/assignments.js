import mongoose from 'mongoose'
const Assignments = new mongoose.Schema({
	url: {
		type: String
	},
	data: {
		type: String
	}
})
export default mongoose.model('assignments', Assignments)
