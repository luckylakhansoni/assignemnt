import Assignment from '../../../../models/assignments';
import jsonwebtoken from 'jsonwebtoken';
// var url = require('url');
const request = require('request');
export async function welcome(ctx) {
	try {
		
		await ctx.render('welcome')

	} catch (error) {
		await ctx.render('error')
	}
}
export async function save(ctx) {
	// try {
		let rep =request('https://timesofindia.indiatimes.com/rss.cms', function(err, res, body) {
			return res
		})
		const result = new Assignment({
			url: ctx.request.body.url,
			data: JSON.stringify(rep)
		})
		const d=await result.save();
		if(d){
			console.log('suuceess')
		}
}
export async function get(ctx) {
		let resp  = await Assignment.find()
		await ctx.render('test',{
			data: resp ? resp : ''
		})
} 