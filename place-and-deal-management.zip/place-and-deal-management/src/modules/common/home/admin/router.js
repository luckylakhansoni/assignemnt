import * as admin from '../admin/controller'
export const baseUrl = '/'
export default [
	{
		method: 'GET',
		route: '/',
		handlers: [
			admin.welcome
		]
	},
	{
		method: 'POST',
		route: 'save/url',
		handlers: [
			admin.save
		]
	},
	{
		method: 'GET',
		route: 'dashboard',
		handlers: [
			admin.get
		]
	}
]
