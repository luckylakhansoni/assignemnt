module.exports = {
	STATUS_CODE: {
		SUCCESS_STATUS: 200,
		NO_CONTENT_STATUS: 204,
		ACCEPTED_STATUS: 202,
		UNPROCESSABLE_ENTITY_STATUS: 422,
		INTERNAL_SERVER_ERROR_STATUS: 500,
		BAD_REQUEST_ERROR_STATUS: 400,
		UNAUTHORIZED_ERROR_STATUS: 401,
		FORBIDDEN_ERROR_STATUS: 403,
		CONFLICT_ERROR_STATUS: 409,
		MOVED_PERMANENTLY: 301,
		NOT_FOUND_STATUS: 404,
		CREATED_SUCCESSFULLY_STATUS: 201
	},
	MESSAGES: {
		USER_NOT_FOUND: 'User not found',
		m1: 'please enter your username and password',
		m2: 'password is wrong',
		m3: 'user already regsiter',
		m4: 'Emai is wrong',
		m5: 'please fill all the fields',
		m6: 'Deal not added beacause place not approved by admin',
		m7: 'Place is not approved',
		m8: 'Deal add succesfully'
	}
}
