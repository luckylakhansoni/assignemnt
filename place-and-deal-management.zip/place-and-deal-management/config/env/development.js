export default {
	session: process.env.SESSION,
	token: process.env.JWT_SECRET,
	database: process.env.DATABASE_URL
}
