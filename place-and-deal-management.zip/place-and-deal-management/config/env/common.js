export default {
	port: process.env.PORT || 3000
}
